package com.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.Student;
import com.demo.repository.StudentRepository;
@RestController
public class HomeController {
	
	@Autowired
	private StudentRepository studentrepository;
	
	@GetMapping("/")
	public String index()
	{
		return "Welcome to Spring boot World!!";
	}
	
	@PostMapping("/saveData")
	public Student saveData(@RequestBody Student student)
	{
		studentrepository.save(student);
		return student;
	}
	@GetMapping("/getAll")
	public List<Student> getAll()
	{
		List<Student> studentList = studentrepository.findAll();
		return studentList;
	}
	@GetMapping("/getStudent/{rollno}")
	public Optional<Student> getStudent(@PathVariable int rollno)
	{
		Optional<Student> student = studentrepository.findById(rollno);
		Student student1 = student.get();
		return student;
	}
	@DeleteMapping("/deleteStudent/{rollno}")
	public String deleteStudent(@PathVariable int rollno)
	{
		Student student = studentrepository.findById(rollno).get();
		if (student != null) {
			studentrepository.delete(student);
		}
		return "Deleted Successfully!!";
	}
	@PutMapping("/updateData")
	public Student updateData(@RequestBody Student student)
	{
		studentrepository.save(student);
		return student;
		
	}
}
