package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudOperation1Application {

	public static void main(String[] args) {
		SpringApplication.run(CrudOperation1Application.class, args);
	}

}
